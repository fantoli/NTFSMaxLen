
package Sensors;

import nwstcrpi.frmMain;


/**
 *
 * @author amartinez
 */
public class Main {
    
    public static void main(String[] args){
        
        mainSensors s1 = new mainSensors();
        s1.setVisible(true);
        
        
        
        //warningWindow w1 = new warningWindow();
        //w1.setVisible(true);
        
    }
    
    
}
